.. _sec_routines:

List of routines
================

You can generate the list and the description of the SCALAPACKFX routines via
doxygen (see folder `doc/doxygen/` in the source tree) or examples as sphix
documentation.
