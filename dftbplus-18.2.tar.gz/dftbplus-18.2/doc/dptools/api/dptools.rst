dptools package
===============

Submodules
----------

dptools.bandout module
----------------------

.. automodule:: dptools.bandout
    :members:
    :undoc-members:
    :show-inheritance:

dptools.cif module
------------------

.. automodule:: dptools.cif
    :members:
    :undoc-members:
    :show-inheritance:

dptools.common module
---------------------

.. automodule:: dptools.common
    :members:
    :undoc-members:
    :show-inheritance:

dptools.gen module
------------------

.. automodule:: dptools.gen
    :members:
    :undoc-members:
    :show-inheritance:

dptools.geometry module
-----------------------

.. automodule:: dptools.geometry
    :members:
    :undoc-members:
    :show-inheritance:

dptools.grids module
--------------------

.. automodule:: dptools.grids
    :members:
    :undoc-members:
    :show-inheritance:

dptools.xyz module
------------------

.. automodule:: dptools.xyz
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: dptools
    :members:
    :undoc-members:
    :show-inheritance:
